# Class Input
python3 project1.py ./inputs/classinput.dat ./outputs/classoutput.out

# My Input
python3 project1.py ./inputs/myinput.dat ./outputs/myoutput.out