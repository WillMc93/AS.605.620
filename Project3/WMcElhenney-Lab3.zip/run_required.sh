python project3.py ./inputs/class_input.txt ./outputs/class_output.out
python project3.py ./inputs/student_input.txt ./outputs/student_output.out